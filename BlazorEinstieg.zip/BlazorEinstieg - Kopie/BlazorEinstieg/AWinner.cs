﻿public abstract class AWinner
{
    protected abstract (string?, string?)? HorizontalWinner();
    protected abstract (string?, string?)? VerticalWinner();
    protected abstract (string?, string?)? DiagonalWinner1();
    protected abstract (string?, string?)? DiagonalWinner2();

    protected virtual (string?, string?)? CheckWinner()
    {
        return HorizontalWinner() ?? VerticalWinner() ?? DiagonalWinner1() ?? DiagonalWinner2();
    }
}