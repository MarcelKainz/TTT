﻿public class TttGame : AWinner, IGame
{
    private readonly string?[,] _field = new string?[3, 3];
    public string? Winner { get; private set; }
    public string? WinType { get; private set; }
    public string? NextPlayer { get; private set; } = "x";

    public string? this[int row, int col] => _field[row, col];

    public void Set(int row, int col)
    {
        if (row < 0 || row >= 3 || col < 0 || col >= 3) return;
        if (_field[row, col] == null && Winner == null)
        {
            _field[row, col] = NextPlayer;
            (Winner, WinType) = CheckWinner() ?? (null, null);
            NextPlayer = (Winner == null) ? (NextPlayer == "x" ? "o" : "x") : null;
        }
    }

    protected override (string?, string?)? HorizontalWinner()
    {
        for (int i = 0; i < 3; i++)
        {
            if (_field[i, 0] != null && _field[i, 0] == _field[i, 1] && _field[i, 1] == _field[i, 2])
                return (_field[i, 0], "Horizontal");
        }
        return (null, null);
    }

    protected override (string?, string?)? VerticalWinner()
    {
        for (int i = 0; i < 3; i++)
        {
            if (_field[0, i] != null && _field[0, i] == _field[1, i] && _field[1, i] == _field[2, i])
                return (_field[0, i], "Vertical");
        }
        return (null, null);
    }

    protected override (string?, string?)? DiagonalWinner1()
    {
        return (_field[0, 0] != null && _field[0, 0] == _field[1, 1] && _field[1, 1] == _field[2, 2]) 
            ? (_field[0, 0], "Diagonal (\\)") : (null, null);
    }

    protected override (string?, string?)? DiagonalWinner2()
    {
        return (_field[0, 2] != null && _field[0, 2] == _field[1, 1] && _field[1, 1] == _field[2, 0]) 
            ? (_field[0, 2], "Diagonal (/)") : (null, null);
    }
}