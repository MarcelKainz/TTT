﻿interface IGame
{
    string? this[int row, int col] { get; }
    string? Winner { get; }
    string? NextPlayer { get; }
    void Set(int row, int col);
}